# TODO

## Stuff to implement

* Cleanup action to remove shows/episodes that have been removed from the database
  * Trigger on database cleanup finished (see Monitor)
  * Trigger on startup
* Manual reset option?
  * Context menu?
    * Per episode
    * Per season
    * Per show
  * Lets see if we need it
* Reset in settings screen?
